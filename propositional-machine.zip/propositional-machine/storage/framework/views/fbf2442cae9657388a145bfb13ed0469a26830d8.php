<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <title>Propositional</title>
</head>
<body>
    <div class="container mt-5 pb-3">
        <div class="row mb-5">
            <h1>Result</h1>
        </div>
        <div class="row mb-5">
            <div class="card text-dark mb-3 text-center">
                <div class="card-header mb-3 bg-success">
                    <h5 class="card-title text-white"><?php echo e($text_message); ?></h5>
                </div>
                <div class="card-body">
                    <?php if($text_message !== "INVALID"): ?>
                    <table class="table table-success table-striped">
                        <thead>
                            <tr>
                                <?php
                                $i=0;
                                ?>
                                <?php while($i < $max_size): ?>
                                <th><?php echo e($variables[$i]); ?></th>
                                <?php
                                $i++;
                                ?>
                                <?php endwhile; ?>
                                <th><?php echo e($left_sentence); ?></th>
                                <th><?php echo e($right_sentence); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i=0;
                            ?>
                            <?php $__currentLoopData = $truth_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php $__currentLoopData = $truths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php  if($truth == "T") echo "True"; else echo "False"; ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php if($left_result[$i] == 1) echo "True"; else echo "False"; ?></td>
                                <td><?php if($right_result[$i] == 1) echo "True"; else echo "False"; ?></td>
                            </tr>
                                <?php
                                $i++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
            <a class="btn btn-primary" href="/">Return to Search Page</a>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\proposition\resources\views/proposition.blade.php ENDPATH**/ ?>