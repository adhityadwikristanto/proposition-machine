<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <title>Propositional</title>
    </head>
    <body>
        <div class="container mt-5 pb-3">
            <div class="row mb-5">
                <h1>Propositional</h1>
            </div>
            <form method="post" action="./proposition">
            <?php echo csrf_field(); ?>
            <div class="row mb-5">
                <div class="form-group">
                    <div class="row mb-3">
                        <label for="left" class="col-sm-2 col-form-label">First Sentence</label>
                        <div class="col-sm-6">
                        <input type="text" class="form-control" id="left" name="left">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="right" class="col-sm-2 col-form-label">Second Sentence</label>
                        <div class="col-sm-6">
                        <input type="text" class="form-control" id="right" name="right">
                        </div>
                    </div>
                    <input type="submit" class="btn btn-primary" value="Is Equivalent?">
                </div>
            </div>
            <div class="row mb-5">
                <div class="alert alert-secondary" role="alert">
                    <h5>
                        Allowed variables to be used are all letters from A to Z except F, T, V, and X.
                    </h5>
                    </br>
                    
                        Operand,
                    
                    </br>
                    
                        AND: ^
                    
                    </br>
                    
                        OR: V
                    
                    </br>
                    
                        NEGATION: ~
                    
                    </br>
                    
                        IMPLY: >
                    
                    </br>
                    
                        IF ONLY IF: <>
                    
                    </br>
                    
                        XOR: <.X.> [without .]
                    
                </div>
            </div>
            </form>
        </div>
    </body>
    </html><?php /**PATH C:\xampp\htdocs\propositional-machine\resources\views/home.blade.php ENDPATH**/ ?>