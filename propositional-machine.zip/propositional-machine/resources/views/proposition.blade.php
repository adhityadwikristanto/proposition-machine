<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <title>Propositional</title>
</head>
<body>
    <div class="container mt-5 pb-3">
        <div class="row mb-5">
            <h1>Result</h1>
        </div>
        <div class="row mb-5">
            <div class="card text-dark mb-3 text-center">
                <div class="card-header mb-3 bg-success">
                    <h5 class="card-title text-white">{{ $text_message }}</h5>
                </div>
                <div class="card-body">
                    @if($text_message !== "INVALID")
                    <table class="table table-success table-striped">
                        <thead>
                            <tr>
                                @php
                                $i=0;
                                @endphp
                                @while($i < $max_size)
                                <th>{{ $variables[$i] }}</th>
                                @php
                                $i++;
                                @endphp
                                @endwhile
                                <th>{{ $left_sentence }}</th>
                                <th>{{ $right_sentence }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                            $i=0;
                            @endphp
                            @foreach($truth_table as $truths)
                            <tr>
                                @foreach($truths as $truth)
                                <td><?php  if($truth == "T") echo "True"; else echo "False"; ?></td>
                                @endforeach
                                <td><?php if($left_result[$i] == 1) echo "True"; else echo "False"; ?></td>
                                <td><?php if($right_result[$i] == 1) echo "True"; else echo "False"; ?></td>
                            </tr>
                                @php
                                $i++;
                                @endphp
                            @endforeach
                        </tbody>
                    </table>
                    @endif
                </div>
            </div>
            <a class="btn btn-primary" href="/">Return to Input Page</a>
        </div>
    </div>
</body>
</html>